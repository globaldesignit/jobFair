
<?php $__env->startSection('content'); ?>
<div class="content login-box">
	<div class="login-main">
		<div class="wrap">
			<h1>CREATE NEW QUESTION</h1>
			<?php if(session('notify')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notify')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
			<div class="register-grids">
				<?php echo Form::open(['route' => 'ques.store', 'class' => 'form-horizontal']); ?>

						<div class="register-top-grid">
							<h3>CREATE NEW QUESTION</h3>
							<div>
								<h5>Question<label>*</label></h5>
								<textarea type="text" name="question" class="form-control" required id="article-ckeditor"> </textarea>
							</div>							
							
                            <div>
                                <h5>Answer 1<label>*</label></h5>
                                <input rows="4"  type="text" name="ans1" class="form-control" required />							
                            </div>	
                            <div>
								<h5>Answer 2<label>*</label></h5>
                                <input  type="text" name="ans2" class="form-control" required/>
                        
                            </div>	
                            <div>
								<h5>Answer 3<label>*</label></h5>
                                <input rows="4"  type="text" name="ans3" class="form-control" required/>
                            </div>	 
                            <div>
								<h5>Answer 4<label>*</label></h5>
                                <input rows="4"  type="text" name="ans4" class="form-control" required />
                            </div>	                            
                            <div>
								<h5>Correct Answer<label>*</label></h5>
								1 <input type="radio" name="correctAns" value="1" required>
                                2 <input type="radio" name="correctAns" value="2" required>
                                3 <input type="radio" name="correctAns" value="3" required>
                                4 <input type="radio" name="correctAns" value="4" required>
                            </div>   
                            <div>
                                <h5>Level<label>*</label></h5>
                                <select name="level" id="level">
                                    <option value='1'>1</option>
                                    <option value='2'>2</option>
                                    <option value='3'>3</option>
                                    <option value='4'>4</option>
                                    <option value='5'>5</option>
                                </select>              
                            </div>	
                            <div>
                                <h5>Type<label>*</label></h5>
                                <select name="typeQues" id="level">
                                <?php $__currentLoopData = $typeQues->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value='<?php echo e($type->type); ?>'><?php echo e($type->type); ?> - Level <?php echo e($type->level); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                              
                                </select>              
                            </div>	
						</div>
						<div class="clear"> </div>					
						<div class="clear"> </div>
						<input type="submit" value="submit" />
						<a href="<?php echo e(route('user.index','admin')); ?>" class="btn btn-danger" style="margin-left: 20px;">Cancel</a>
				<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'article-ckeditor' );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>