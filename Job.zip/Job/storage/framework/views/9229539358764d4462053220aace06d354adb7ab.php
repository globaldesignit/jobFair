
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
<?php if(session('notify')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notify')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
  <div class="panel panel-default">
    <div class="panel-heading">
      <i class="fa fa-table"></i><h5>List Question</h5>
    </div>
    <div class="panel-body">
      <table width="100%" class="table table-striped table-bordered table-hover">
        <thead>
          <tr>            
            <th>Question</th>
            <th>Answer 1</th>
            <th>Answer 2</th>
            <th>Answer 3</th>
            <th>Answer 4</th>    
            <th>Correct answer</th>   
            <th>Type</th>
            <th>Level</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="gradeX">
              <td>
              <div style=" white-space: nowrap; width: 500px; overflow: hidden;  text-overflow: ellipsis; "><?php echo e($questions->question); ?></div>
              </td>
              <td><?php echo e($questions->ans1); ?></td>
              <td><?php echo e($questions->ans2); ?></td>
              <td><?php echo e($questions->ans3); ?></td>
              <td><?php echo e($questions->ans4); ?></td>
              <td><?php echo e($questions->correctAns); ?></td>
              <td><?php echo e($questions->typeQues); ?></td>
              <td><?php echo e($questions->level); ?></td>
              <td><a href="<?php echo e(route('ques.edit', ['id'=>$questions->id])); ?>" class="btn btn-info" >Edit</a></td>            
              </td>
              <td>
              <?php echo Form::open(['method' => 'delete', 'action' => ['QuestionController@destroy', $questions->id]]); ?>

              <?php echo Form::submit('Delete', ['onclick'=>"return confirm('Delete questions?')", 'class' => 'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>