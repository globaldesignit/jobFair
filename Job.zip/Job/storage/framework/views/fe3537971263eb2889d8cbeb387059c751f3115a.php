<script type="text/javascript">
	$(document).ready(function(){
		//con loi back
		$(document).ajaxComplete(function(ev, jqXHR, settings) {
		    var stateObj = { url: settings.url, innerhtml: document.body.innerHTML };
		    // window.history.pushState(stateObj, settings.url, settings.url); change href
		    window.history.pushState(stateObj, settings.url);
		});


		window.onpopstate = function (event) {
		    var currentState = history.state;
		    document.body.innerHTML = currentState.innerhtml;
		};

		// Adding popstate event listener to handle browser back button  
        // window.addEventListener("popstate", function (e) {
        //     $.ajax({
        //         url: location.href,
        //         success: function (result) {
        //             $('.content').html(result);
        //         }
        //     });
        // });
		//load cart
	  
	    //change day dd-mm-yyyy
	});
</script>	