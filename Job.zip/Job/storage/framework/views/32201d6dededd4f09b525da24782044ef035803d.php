
<?php $__env->startSection('content'); ?>
<div class="content login-box">
	<div class="login-main">
		<div class="wrap">		
			<div class="login-left">
				<h3>REGISTERED CUSTOMERS</h3>
				<p>If you have an account with us, please log in.</p>
				<?php if(session('notify')): ?>
	                <div class="alert alert-danger">
	                    <?php echo e(session('notify')); ?>

	                </div>
                <?php endif; ?>
                <?php echo Form::open(['route' => 'user.login', 'method' => 'POST','class' => 'form-horizontal']); ?>

					<div>
						<span>User<label>*</label></span>
						<input type="text" name="User" placeholder="User" class="form-control"> 
					</div>
					<div>
						<span>Password<label>*</label></span>
						<input type="password" name="password" class="form-control" placeholder="Password"> 
					</div>
		
					<input type="submit" value="Login" />
				<?php echo Form::close(); ?>

			</div>
			<div class="clear"> </div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>