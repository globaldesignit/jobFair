
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
<?php if(session('notify')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notify')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
  <div class="panel panel-default">
    <div class="panel-heading">
      <i class="fa fa-table"></i><h5>List result</h5>
    </div>
    <form action="<?php echo e(route('res.search')); ?>" method="POST" role="search" style ="margin-bottom:10px;">
        <?php echo e(csrf_field()); ?>

        <div class="input-group">
            <input type="text" class="form-control" name="search"
                placeholder="Search..."> <span class="input-group-btn">
                <button type="submit" class="btn btn-default" style="margin-left:10px;">
                    <span class="glyphicon glyphicon-search">Search</span>
                </button>
            </span>
        </div>
    </form>
       <div class="data-grids">    
       <table width="100%" class="table table-striped table-bordered table-hover">
        <thead>
          <tr>            
            <th><a href="<?php echo e(route('res.orderBy',['order'=>'localTest'])); ?>">Location</a></th>
            <th><a href="<?php echo e(route('res.orderBy',['order'=>'name'])); ?>">Name</a></th>
            <th><a href="<?php echo e(route('res.orderBy',['order'=>'mail'])); ?>">Mail</a></th>
            <th><a href="<?php echo e(route('res.orderBy',['order'=>'phone'])); ?>">Phone</a></th>
            <th><a href="<?php echo e(route('res.orderBy',['order'=>'total'])); ?>">Total</a></th>     
            <th><a href="<?php echo e(route('res.orderBy',['order'=>'result'])); ?>">Result</a></th>
            <th><a href="<?php echo e(route('res.orderBy',['order'=>'status'])); ?>">Status</a></th>
            <th><a href="<?php echo e(route('res.orderBy',['order'=>'created_at'])); ?>">Date</a></th>           
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="gradeX">
              <td><?php echo e($res->localTest); ?></td>
              <td><?php echo e($res->name); ?></td>
              <td><?php echo e($res->mail); ?></td>
              <td><?php echo e($res->phone); ?></td>
              <td><?php echo e($res->total); ?></td>
              <td><?php echo e($res->result); ?></td>
              <?php if($res->status ==1): ?>
              <td style="color:green; font-weight:bold">Pass</td>
              <?php else: ?>
              <td style="color:red; font-weight:bold">Not pass</td>
              <?php endif; ?>
              <td><?php echo e($res->created_at); ?></td>              
              <td>
              <?php echo Form::open(['method' => 'delete', 'action' => ['ResultController@destroy', $res->id]]); ?>

              <?php echo Form::submit('Delete', ['onclick'=>"return confirm('Delete result?')", 'class' => 'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>       
</table>
        <div class="containpagination">
            <?php if(!isset($all)): ?>
                <?php echo e($results->render()); ?>

            <?php endif; ?>
        </div>
        </div>

    </div>
    
  </div>
</div>
<?php $__env->stopSection(); ?>
<!-- <?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            var status= true;
            console.log(status);
            $('#mail').on('click', function(e) {
                status= !status;
                console.log(status);      
                document.getElementById("mail").href="<?php echo e(route('res.orderBy',['order'=>'mail'])); ?>";       
  
            });            

            $("#search").change(function(e){
                var url = '<?php echo e(route('res.search', ['id' => ''])); ?>'+'/'+this.value;
                console.log(this.value)
               $.ajax(
                    {
                        url: url,

                        type: 'GET',

                    }).done( 
                        function(data) 
                        {                          
                            $('.data-grids').html(data);
                        }

                    );          
            });
            $("#numpage").change(function(e){
                var url = '<?php echo e(route('res.index', ['id' => ''])); ?>'+'/'+this.value;
               $.ajax(
                    {
                        url: url,

                        type: 'GET',

                    }).done( 
                        function(data) 
                        {                          
                            $('qbody').html(data);
                        }

                    );          
            });
            $("#numpage").change();
        });
    </script>
<?php $__env->stopSection(); ?> -->

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>