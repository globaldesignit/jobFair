
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
<?php if(session('notify')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notify')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
  <div class="panel panel-default">
    <div class="panel-heading">
      <i class="fa fa-table"></i><h5>List type question</h5>
    </div>
    <div class="panel-body">
      <table width="100%" class="table table-striped table-bordered table-hover">
        <thead>
          <tr>            
            <th>Type</th>
            <th>Level</th>
            <th>Limit</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="gradeX">
              <td><?php echo e($type->type); ?></td>
              <td><?php echo e($type->level); ?></td>
              <td><?php echo e($type->limit); ?></td>         
              <td><a href="<?php echo e(route('type.edit', ['id'=>$type->id])); ?>" class="btn btn-info" >Edit</a></td>            
              </td>
              <td>
              <?php echo Form::open(['method' => 'delete', 'action' => ['TypeController@destroy', $type->id]]); ?>

              <?php echo Form::submit('Delete', ['onclick'=>"return confirm('Delete this type?')", 'class' => 'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>