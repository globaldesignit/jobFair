@extends('layout.layout')
@section('content')
<h3>Giới thiệu về GDIT</h3>
<span>
Được thành lập vào năm 2016, cho đến hiện tại chúng tôi chủ yếu phát triển các product của công ty mẹ là Global Design, nhưng chúng tôi cũng có thể đáp ứng được yêu cầu từ nhiều công ty hơn nữa. 
Với niềm đam mê, nỗ lực và được sự tin tưởng của khách hàng, chúng tôi có thể đáp ứng được yêu cầu từ quy mô nhỏ đến lớn cũng như ở phát triển dạng Labor.</span>
@stop
