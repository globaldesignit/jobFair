
<?php $__env->startSection('content'); ?>
<p>Hoàn thành bài kiểm tra!</p><br/>
<h3>Kết quả:</h3>
<?php if($status==1): ?>
<span>Bạn đã vượt qua bài thi</span>
<?php else: ?>
<span>Bạn đã không vượt qua bài thi</span>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>