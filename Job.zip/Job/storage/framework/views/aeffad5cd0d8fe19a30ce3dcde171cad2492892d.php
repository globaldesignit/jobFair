
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
<?php if(session('notify')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notify')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
  <div class="panel panel-default">
    <div class="panel-heading">
      <i class="fa fa-table"></i><h5>List location test</h5>
    </div>
    <div class="panel-body">
      <table width="100%" class="table table-striped table-bordered table-hover">
        <thead>
          <tr>            
            <th>Location</th>
            <th>Level</th>
            <th>Short name</th>
            <th>Status</th>
            <th>Percent pass</th>
            <th></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="gradeX">
              <td><?php echo e($location->name); ?></td>
              <td><?php echo e($location->level); ?></td>
              <td><?php echo e($location->shortName); ?></td>
              <td><?php echo e($location->percentPass); ?></td>
              <?php if($location->status==1): ?>
              <td>Đã kích hoạt</td>          
              <?php else: ?>
              <td>Chưa kích hoạt</td>
              <?php endif; ?>   
              <td><a href="<?php echo e(route('loca.edit', ['id'=>$location->id])); ?>" class="btn btn-info" >Edit</a></td>            
              </td>
              <td>
              <?php echo Form::open(['method' => 'delete', 'action' => ['LocationController@destroy', $location->id]]); ?>

              <?php echo Form::submit('Delete', ['onclick'=>"return confirm('Delete location?')", 'class' => 'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>