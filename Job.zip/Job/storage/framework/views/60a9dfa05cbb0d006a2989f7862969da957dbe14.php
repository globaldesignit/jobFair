<table width="100%" class="table table-striped table-bordered table-hover">
        <thead>
          <tr>            
            <th>Location</th>
            <th>Name</th>
            <th>Mail</th>
            <th>Phone</th>
            <th>Total</th>    
            <th>Result</th>   
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="gradeX">
              <td><?php echo e($res->localTest); ?></td>
              <td><?php echo e($res->name); ?></td>
              <td><?php echo e($res->mail); ?></td>
              <td><?php echo e($res->phone); ?></td>
              <td><?php echo e($res->total); ?></td>
              <td><?php echo e($res->result); ?></td>
              <td><?php echo e($res->created_at); ?></td>              
              <td>
              <?php echo Form::open(['method' => 'delete', 'action' => ['ResultController@destroy', $res->id]]); ?>

              <?php echo Form::submit('Delete', ['onclick'=>"return confirm('Delete result?')", 'class' => 'btn btn-danger']); ?>

              <?php echo Form::close(); ?>

              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>       
</table>
<div class="containpagination">
    <?php if(!isset($all)): ?>
        <?php echo e($results->render()); ?>

    <?php endif; ?>
</div>