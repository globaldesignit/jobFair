<div class="top-header-main">    
    <div class="top-header-main">
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-success" style="position: fixed; padding: 5px; z-index: 1; opacity: 0.4;">Home</a>
        <div class="wrap">              
            <div class="top-header-right">
            <?php if(Auth::guard('users')->check()): ?>
                <ul>
                    <li><a>Welcome: <?php echo e(Auth::guard('users')->user()->User); ?></a><span> </span></li>
                    <li><a href="<?php echo e(route('user.logout')); ?>">Log Out</a></li>
           
                    <p><?php echo e(Auth::guard('users')->user()->id); ?></p><br>
                    <p><?php echo e(Auth::guard('users')->user()->name); ?></p><br>
                    <p><?php echo e(Auth::guard('users')->user()->email); ?></p><br>                  
                  
                </ul>
            <?php else: ?>
                <ul>
                    <li><a href="<?php echo e(route('user.login')); ?>">Log In</a><span> </span></li>
                </ul>
            <?php endif; ?>
            </div>
            <div class="clear"> </div>
        </div>
    </div>   
    <div class="header-bottom">
        <div class="wrap">
                <ul class="megamenu skyblue">
                     <li class="grid">
                        
                    </li>                   
                </ul>

        </div>
    </div>
</div>