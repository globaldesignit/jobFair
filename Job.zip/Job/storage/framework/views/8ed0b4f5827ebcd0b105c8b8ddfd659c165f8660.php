
<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route' => ['contest.post', 'loca'=> $loca], 'class' => 'form-horizontal']); ?>


<p> The test will be out in <span id="countdowntimerM"> </span> minutes <span id="countdowntimerS">  </span> seconds</p>

<?php for($i = 0 ; $i < count($questions) ; $i++): ?>
		<h4>Q<?php echo e($i+1); ?>:</h4>	<?php echo $questions[$i]->question; ?>	
		</br>
		<?php echo e(Form::radio(  $questions[$i]->id,  $questions[$i]->ans1,  false, array('id'=> $questions[$i]->id ))); ?>

		<span> <?php echo e($questions[$i]->ans1); ?></span></br>
		<?php echo e(Form::radio(  $questions[$i]->id,  $questions[$i]->ans2,  false, array('id'=> $questions[$i]->id ))); ?>

		<span> <?php echo e($questions[$i]->ans2); ?></span></br>
		<?php echo e(Form::radio(  $questions[$i]->id,  $questions[$i]->ans3,  false, array('id'=> $questions[$i]->id ))); ?>

		<span> <?php echo e($questions[$i]->ans3); ?></span></br>
		<?php echo e(Form::radio(  $questions[$i]->id,  $questions[$i]->ans4,  false, array('id'=> $questions[$i]->id  ))); ?>

		<span> <?php echo e($questions[$i]->ans4); ?></span></br>
		</br>
		
<?php endfor; ?>
<input type="hidden" name="countQues" value="<?php echo e($countQues); ?>"/>
<input type="submit" id="submit" value="submit" />
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">		
	var timeleft = sessionStorage.getItem("timeLeft");
	var timeM = parseInt((sessionStorage.getItem("timeLeft"))/60);
	document.getElementById("countdowntimerM").textContent = timeM;
	document.getElementById("countdowntimerS").textContent = timeleft % 60;
    var downloadTimer = setInterval(function(){
	if(timeleft >0)
	{
    timeleft--;
	sessionStorage.setItem("timeLeft", timeleft);
	}	
    document.getElementById("countdowntimerS").textContent = timeleft % 60;
	timeM = parseInt((sessionStorage.getItem("timeLeft")-1)/60);
	document.getElementById("countdowntimerM").textContent = timeM;
	if(timeleft <=0)
	{
		alert("Time out!!")
		form =document.getElementById("submit");
		form.click();
	}
    if(timeleft <= 0)
        clearInterval(downloadTimer);
    },1000);

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>