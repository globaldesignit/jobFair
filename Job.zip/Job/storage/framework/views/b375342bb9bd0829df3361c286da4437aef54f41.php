
<?php $__env->startSection('css'); ?>
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
  margin-top:5px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}


.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-12"><?php if(session('notify')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('notify')); ?>

                </div>
            <?php endif; ?>
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
  <div class="panel panel-default">
    <div class="panel-heading">
      <i class="fa fa-align-justify"></i><h5>Edit Question</h5>
    </div>
    <div class="panel-body">
    <?php echo Form::model($location, ['method'=>'PATCH', 'action'=>['LocationController@update', $location->id],'class' => 'form-horizontal']); ?>


        <div class="control-group">
          <label class="control-label required">Name: </label>
          <div class="controls">
            <input type="text" name="name" class="form-control" required value="<?php echo e($location->name); ?>" autofocus />
          </div>
        </div>
        <div class="control-group">
          <label class="control-label required">Short name: </label>
          <div class="controls">
            <input type="text" name="shortName" class="form-control" required value="<?php echo e($location->shortName); ?>" id="taikhoan" />
          </div>
        </div>    
     
        <div>
            <h5>Level<label>*</label></h5>
              <select name="level" id="level">
                 <?php if(1 == $location->level): ?>                  
                    <option value='1' selected>1</option>
                  <?php else: ?>
                    <option value='1'>1</option>
                  <?php endif; ?>    
                  <?php if(2 == $location->level): ?>                  
                    <option value='2' selected>2</option>
                  <?php else: ?>
                    <option value='2'>2</option>
                  <?php endif; ?>
                  <?php if(3 == $location->level): ?>                  
                    <option value='3' selected>3</option>
                  <?php else: ?>
                    <option value='3'>3</option>
                  <?php endif; ?>
                  <?php if(4 == $location->level): ?>                  
                    <option value='4' selected>4</option>
                  <?php else: ?>
                    <option value='4'>4</option>
                  <?php endif; ?>
                  <?php if(5 == $location->level): ?>                  
                    <option value='5' selected>5</option>
                  <?php else: ?>
                    <option value='5'>5</option>
                  <?php endif; ?>            
              </select>
         </div>     
         <div>
            <h5>Percent pass<label>*</label></h5>
              <select name="percentPass" id="percentPass">
                 <?php if(30 == $location->percentPass): ?>                  
                    <option value='30' selected>30%</option>
                  <?php else: ?>
                    <option value='30'>30%</option>
                  <?php endif; ?>    
                  <?php if(40 == $location->percentPass): ?>                  
                    <option value='40' selected>40%</option>
                  <?php else: ?>
                    <option value='40'>40%</option>
                  <?php endif; ?>
                  <?php if(50 == $location->percentPass): ?>                  
                    <option value='50' selected>50%</option>
                  <?php else: ?>
                    <option value='50'>50%</option>
                  <?php endif; ?>
                  <?php if(60 == $location->percentPass): ?>                  
                    <option value='60' selected>60%</option>
                  <?php else: ?>
                    <option value='60'>60%</option>
                  <?php endif; ?>
                  <?php if(70 == $location->percentPass): ?>                  
                    <option value='70' selected>70%</option>
                  <?php else: ?>
                    <option value='70'>70%</option>
                  <?php endif; ?>  
                  <?php if(80 == $location->percentPass): ?>                  
                    <option value='80' selected>80%</option>
                  <?php else: ?>
                    <option value='80'>80%</option>
                  <?php endif; ?>
                  <?php if(90 == $location->percentPass): ?>                  
                    <option value='90' selected>90%</option>
                  <?php else: ?>
                    <option value='90'>90%</option>
                  <?php endif; ?>
                  <?php if(100 == $location->percentPass): ?>                  
                    <option value='100' selected>100%</option>
                  <?php else: ?>
                    <option value='100'>100%</option>
                  <?php endif; ?>           
              </select>
         </div>     
         <div>
         <h5>Status<label>*</label></h5>
         <label class="switch">
           <?php if($location->status ==1): ?>
            <input type="checkbox" checked name="status">
            <?php else: ?>
            <input type="checkbox"  name="status">
            <?php endif; ?>
            <span class="slider round"></span>
        </label>
        </div>
        <div class="form-actions">
          <input type="submit" class="btn btn-primary btn-large" value="Save">
          <a class="btn btn-danger" style="margin-left: 50px;">Cancel</a>
        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>